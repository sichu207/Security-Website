<?php
class PasswordPolicyManager {
    private $conn;
    private $settings = [];
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->loadSettings();
    }
    
    // Load password policy settings from database
    private function loadSettings() {
        $stmt = $this->conn->prepare("SELECT setting_name, setting_value FROM password_policy_settings");
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $this->settings[$row['setting_name']] = $row['setting_value'];
        }
        $stmt->close();
    }
    
    // Get a specific setting
    public function getSetting($setting_name, $default = null) {
        return $this->settings[$setting_name] ?? $default;
    }
    
    // Check if user account is locked
    public function isAccountLocked($user_id) {
        $stmt = $this->conn->prepare("SELECT account_locked_until FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user || !$user['account_locked_until']) {
            return false;
        }
        
        $lockout_until = new DateTime($user['account_locked_until']);
        $now = new DateTime();
        
        if ($now < $lockout_until) {
            return true; // Account is still locked
        } else {
            // Lockout period has expired, unlock the account
            $this->unlockAccount($user_id);
            return false;
        }
    }
    
    // Lock user account
    public function lockAccount($user_id) {
        $lockout_duration = (int)$this->getSetting('lockout_duration_minutes', 30);
        $lockout_until = date('Y-m-d H:i:s', strtotime("+{$lockout_duration} minutes"));
        
        $stmt = $this->conn->prepare("UPDATE users SET account_locked_until = ? WHERE id = ?");
        $stmt->bind_param("si", $lockout_until, $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Unlock user account
    public function unlockAccount($user_id) {
        $stmt = $this->conn->prepare("UPDATE users SET account_locked_until = NULL, failed_login_attempts = 0 WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Increment failed login attempts
    public function incrementFailedAttempts($user_id) {
        $max_attempts = (int)$this->getSetting('max_failed_attempts', 3);
        
        $stmt = $this->conn->prepare("UPDATE users SET failed_login_attempts = failed_login_attempts + 1 WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        
        // Check if account should be locked
        $stmt = $this->conn->prepare("SELECT failed_login_attempts FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if ($user && $user['failed_login_attempts'] >= $max_attempts) {
            $this->lockAccount($user_id);
            return true; // Account is now locked
        }
        
        return false;
    }
    
    // Reset failed login attempts on successful login
    public function resetFailedAttempts($user_id) {
        $stmt = $this->conn->prepare("UPDATE users SET failed_login_attempts = 0 WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Check if password has expired
    public function isPasswordExpired($user_id) {
        $stmt = $this->conn->prepare("SELECT password_expires_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user || !$user['password_expires_at']) {
            return false;
        }
        
        $expires_at = new DateTime($user['password_expires_at']);
        $now = new DateTime();
        
        return $now >= $expires_at;
    }
    
    // Check if password will expire soon (within 7 days)
    public function isPasswordExpiringSoon($user_id) {
        $stmt = $this->conn->prepare("SELECT password_expires_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user || !$user['password_expires_at']) {
            return false;
        }
        
        $expires_at = new DateTime($user['password_expires_at']);
        $now = new DateTime();
        $seven_days = new DateTime('+7 days');
        
        return $now < $expires_at && $expires_at <= $seven_days;
    }
    
    // Check if password is in history (prevents reuse of last N passwords)
    public function isPasswordInHistory($user_id, $password) {
        $history_count = (int)$this->getSetting('password_history_count', 3);
        
        $stmt = $this->conn->prepare("SELECT password_hash FROM password_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("ii", $user_id, $history_count);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            if (password_verify($password, $row['password_hash'])) {
                $stmt->close();
                return true;
            }
        }
        
        $stmt->close();
        return false;
    }
    
    // Add password to history
    public function addPasswordToHistory($user_id, $password_hash) {
        $stmt = $this->conn->prepare("INSERT INTO password_history (user_id, password_hash, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $password_hash);
        $stmt->execute();
        $stmt->close();
    }
    
    // Update password and set expiry
    public function updatePassword($user_id, $new_password) {
        $expiry_days = (int)$this->getSetting('password_expiry_days', 90);
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT, ['cost' => 12]);
        $expires_at = date('Y-m-d H:i:s', strtotime("+{$expiry_days} days"));
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Add current password to history before updating
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            if ($user && $user['password']) {
                $this->addPasswordToHistory($user_id, $user['password']);
            }
            
            // Update user password
            $stmt = $this->conn->prepare("UPDATE users SET password = ?, password_changed_at = NOW(), password_expires_at = ?, password_policy_version = password_policy_version + 1 WHERE id = ?");
            $stmt->bind_param("ssi", $password_hash, $expires_at, $user_id);
            $stmt->execute();
            $stmt->close();
            
            // Reset failed attempts and unlock account
            $this->resetFailedAttempts($user_id);
            $this->unlockAccount($user_id);
            
            $this->conn->commit();
            return true;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("Password update failed: " . $e->getMessage());
            return false;
        }
    }
    
    // Validate password against policy
    public function validatePassword($password, $user_id = null) {
        $errors = [];
        
        // Check minimum length
        $min_length = (int)$this->getSetting('min_password_length', 8);
        if (strlen($password) < $min_length) {
            $errors[] = "Password must be at least {$min_length} characters long.";
        }
        
        // Check maximum length
        if (strlen($password) > 128) {
            $errors[] = "Password is too long (maximum 128 characters).";
        }
        
        // Check for uppercase letters
        if ($this->getSetting('require_uppercase', '1') == '1' && !preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter.";
        }
        
        // Check for lowercase letters
        if ($this->getSetting('require_lowercase', '1') == '1' && !preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter.";
        }
        
        // Check for numbers
        if ($this->getSetting('require_numbers', '1') == '1' && !preg_match('/\d/', $password)) {
            $errors[] = "Password must contain at least one number.";
        }
        
        // Check for special characters
        if ($this->getSetting('require_special_chars', '1') == '1' && !preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = "Password must contain at least one special character.";
        }
        
        // Check for common passwords
        if ($this->getSetting('prevent_common_passwords', '1') == '1') {
            $common_passwords = [
                '123456', 'password', '12345678', 'qwerty', 'abc123',
                '111111', '123123', 'password1', '123456789', 'admin',
                'letmein', 'welcome', 'monkey', '1234567', '1234567890'
            ];
            
            if (in_array(strtolower($password), $common_passwords)) {
                $errors[] = "This password is too common. Please choose a stronger password.";
            }
        }
        
        // Check password history (only if user_id is provided)
        if ($user_id && $this->isPasswordInHistory($user_id, $password)) {
            $history_count = $this->getSetting('password_history_count', 3);
            $errors[] = "You cannot reuse your last {$history_count} passwords.";
        }
        
        return $errors;
    }
    
    // Get password expiry information
    public function getPasswordExpiryInfo($user_id) {
        $stmt = $this->conn->prepare("SELECT password_changed_at, password_expires_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            return null;
        }
        
        $info = [
            'changed_at' => $user['password_changed_at'],
            'expires_at' => $user['password_expires_at'],
            'is_expired' => false,
            'is_expiring_soon' => false,
            'days_until_expiry' => null
        ];
        
        if ($user['password_expires_at']) {
            $expires_at = new DateTime($user['password_expires_at']);
            $now = new DateTime();
            $diff = $now->diff($expires_at);
            
            $info['is_expired'] = $now >= $expires_at;
            $info['is_expiring_soon'] = $now < $expires_at && $expires_at <= (new DateTime('+7 days'));
            $info['days_until_expiry'] = $info['is_expired'] ? 0 : $diff->days;
        }
        
        return $info;
    }
    
    // Get account lockout information
    public function getAccountLockoutInfo($user_id) {
        $stmt = $this->conn->prepare("SELECT failed_login_attempts, account_locked_until FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            return null;
        }
        
        $max_attempts = (int)$this->getSetting('max_failed_attempts', 3);
        $lockout_duration = (int)$this->getSetting('lockout_duration_minutes', 30);
        
        $info = [
            'failed_attempts' => $user['failed_login_attempts'],
            'max_attempts' => $max_attempts,
            'remaining_attempts' => max(0, $max_attempts - $user['failed_login_attempts']),
            'is_locked' => false,
            'locked_until' => $user['account_locked_until'],
            'lockout_duration_minutes' => $lockout_duration
        ];
        
        if ($user['account_locked_until']) {
            $locked_until = new DateTime($user['account_locked_until']);
            $now = new DateTime();
            $info['is_locked'] = $now < $locked_until;
        }
        
        return $info;
    }
}
?> 