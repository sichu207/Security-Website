<?php
include 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/Exception.php';
require './PHPMailer/PHPMailer.php';
require './PHPMailer/SMTP.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Generate 6-digit OTP
        $otp = sprintf("%06d", mt_rand(0, 999999));
        $expiry = date("Y-m-d H:i:s", strtotime("+10 minutes"));

        $user = $result->fetch_assoc();

        // Debug: Log the OTP being generated
        error_log("Generated OTP: $otp for email: $email, expiry: $expiry");

        // Store OTP in DB
        $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?");
        $update->bind_param("ssi", $otp, $expiry, $user['id']);
        $update->execute();
        
        // Debug: Verify OTP was stored
        $verify_stmt = $conn->prepare("SELECT reset_token, reset_expiry FROM users WHERE id = ?");
        $verify_stmt->bind_param("i", $user['id']);
        $verify_stmt->execute();
        $verify_result = $verify_stmt->get_result();
        if ($verify_result->num_rows > 0) {
            $verify_user = $verify_result->fetch_assoc();
            error_log("Stored OTP: " . $verify_user['reset_token'] . ", Expiry: " . $verify_user['reset_expiry']);
        }

        // Setup email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'maharjansichu84@gmail.com';  // your Gmail
            $mail->Password = 'gyfbfspwwjmxdhda';           // app password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('maharjansichu84@gmail.com', 'App');
            $mail->addAddress($email);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body = "Hi,\n\nYour password reset OTP is: $otp\n\nThis OTP will expire in 10 minutes.\n\nIf you didn't request this, please ignore this email.";

            $mail->send();

            // Store email in session for OTP verification
            session_start();
            $_SESSION['reset_email'] = $email;

            // ✅ Redirect to OTP verification page
            header("Location: reset_otp_verification.php");
            exit();

        } catch (Exception $e) {
            $message = "Email could not be sent. Mailer Error: " . $mail->ErrorInfo;
        }
    } else {
        $message = "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="centered-form">
        <div class="container">
            <h2>Forgot Password</h2>
            <?php if ($message)
                echo "<p class='error'>$message</p>"; ?>
            <form method="POST" action="">
                <label>Email Address:</label>
                <input type="email" name="email" required placeholder="Enter your registered email">
                <input type="submit" value="Send Reset OTP" class="small-btn">
            </form>
        </div>
    </div>
</body>

</html>