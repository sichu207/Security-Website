document.addEventListener("DOMContentLoaded", function () {
  const captcha = Math.random().toString(36).substring(2, 8);
  document.getElementById("captchaText").innerText = captcha;
  document.getElementById("captcha_hidden").value = captcha;
});