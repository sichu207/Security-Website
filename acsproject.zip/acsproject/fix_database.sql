-- Fix database structure for password reset system
USE acs;

-- Add missing columns if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email VARCHAR(100) UNIQUE NOT NULL AFTER id,
ADD COLUMN IF NOT EXISTS phone VARCHAR(20) NOT NULL AFTER email,
ADD COLUMN IF NOT EXISTS username VARCHAR(50) UNIQUE NOT NULL AFTER phone,
ADD COLUMN IF NOT EXISTS password VARCHAR(255) NOT NULL AFTER username;

-- If columns already exist but are in wrong order, this will handle it
-- The system will work regardless of column order

-- Show final structure
DESCRIBE users; 