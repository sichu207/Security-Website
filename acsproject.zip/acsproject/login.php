<?php
session_start();
include 'db.php'; // Ensure this sets up $conn correctly
include 'session_manager.php'; // Include session manager
include 'password_policy_manager.php'; // Include password policy manager

// Initialize managers
$sessionManager = new SessionManager($conn);
$passwordPolicy = new PasswordPolicyManager($conn);

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/Exception.php';
require './PHPMailer/PHPMailer.php';
require './PHPMailer/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = $_POST['password'];

    // Optional: reCAPTCHA
    if (isset($_POST['g-recaptcha-response'])) {
        $recaptchaResponse = $_POST['g-recaptcha-response'];
        $secretKey = "6LeTJ2orAAAAAKtK3Us_eKpCjSthFQnMpiCelFPX"; // replace with your key
        $verifyResponse = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptchaResponse");
        $captcha = json_decode($verifyResponse);
        if (!$captcha->success) {
            // Log failed login attempt
            $sessionManager->logLoginAttempt(null, $username, 'failure', 'reCAPTCHA failed');
            header('Location: login.html?error=' . urlencode('reCAPTCHA failed.'));
            exit();
        }
    }

    // Fetch user
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check user
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Check if account is locked
        if ($passwordPolicy->isAccountLocked($user['id'])) {
            $lockout_info = $passwordPolicy->getAccountLockoutInfo($user['id']);
            $locked_until = new DateTime($lockout_info['locked_until']);
            $now = new DateTime();
            $remaining_minutes = $now->diff($locked_until)->i;
            
            $sessionManager->logLoginAttempt($user['id'], $user['email'], 'failure', 'Account locked');
            header('Location: login.html?error=' . urlencode("Account is locked. Please try again in {$remaining_minutes} minutes."));
            exit();
        }
        
        // Check if password has expired
        if ($passwordPolicy->isPasswordExpired($user['id'])) {
            $sessionManager->logLoginAttempt($user['id'], $user['email'], 'failure', 'Password expired');
            header('Location: login.html?error=' . urlencode('Your password has expired. Please reset your password.'));
            exit();
        }
        
        if (password_verify($password, $user['password'])) {
            // Password is correct - check if password is expiring soon
            $expiry_warning = '';
            if ($passwordPolicy->isPasswordExpiringSoon($user['id'])) {
                $expiry_info = $passwordPolicy->getPasswordExpiryInfo($user['id']);
                $expiry_warning = " (Password expires in {$expiry_info['days_until_expiry']} days)";
            }
            
            // Reset failed login attempts on successful login
            $passwordPolicy->resetFailedAttempts($user['id']);
            
            // Generate OTP
            $otp = rand(100000, 999999);
            $otp_expiry = date("Y-m-d H:i:s", strtotime("+3 minutes"));

            // Send OTP
            $subject = "Your OTP for Login";
            $message = "Your OTP is: $otp" . $expiry_warning;

            $mail = new PHPMailer(true);

            try {
                $mail->SMTPDebug = 2;               // Enable verbose debug output (0 to disable)
                $mail->Debugoutput = 'html';        // Output format for debugging
                
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'maharjansichu84@gmail.com'; // your email
                $mail->Password = 'gyfbfspwwjmxdhda';       // app password
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('maharjansichu84@gmail.com', 'App');
                $mail->addAddress($user['email']);
                $mail->Subject = $subject;
                $mail->Body = $message;

                $mail->SMTPDebug = 2;               // Enable verbose debug output (0 to disable)
                $mail->Debugoutput = 'html';   
                $mail->send();

                // Save OTP and expiry in DB
                $sql1 = "UPDATE users SET otp='$otp', otp_expiry='$otp_expiry' WHERE id=" . $user['id'];
                mysqli_query($conn, $sql1);

                // Log successful login attempt (before OTP verification)
                $sessionManager->logLoginAttempt($user['id'], $user['email'], 'success', 'OTP sent for verification' . $expiry_warning);

                $_SESSION['temp_user'] = ['id' => $user['id'], 'email' => $user['email']];
                header("Location: otp_verification.php");
                exit();

            } catch (Exception $e) {
                // Log failed login attempt due to email error
                $sessionManager->logLoginAttempt($user['id'], $user['email'], 'failure', 'Email sending failed: ' . $mail->ErrorInfo);
                header('Location: login.html?error=' . urlencode('Mailer Error: ' . $mail->ErrorInfo));
                exit();
            }

        } else {
            // Password is incorrect - increment failed attempts
            $account_locked = $passwordPolicy->incrementFailedAttempts($user['id']);
            
            if ($account_locked) {
                $sessionManager->logLoginAttempt($user['id'], $user['email'], 'failure', 'Account locked due to too many failed attempts');
                header('Location: login.html?error=' . urlencode('Too many failed attempts. Account locked for 30 minutes.'));
            } else {
                $lockout_info = $passwordPolicy->getAccountLockoutInfo($user['id']);
                $remaining_attempts = $lockout_info['remaining_attempts'];
                
                $sessionManager->logLoginAttempt($user['id'], $user['email'], 'failure', 'Incorrect password');
                header('Location: login.html?error=' . urlencode("Incorrect password. {$remaining_attempts} attempts remaining."));
            }
            exit();
        }
    } else {
        // Log failed login attempt for non-existent user
        $sessionManager->logLoginAttempt(null, $username, 'failure', 'User not found');
        header('Location: login.html?error=' . urlencode('User not found.'));
        exit();
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: login.html");
    exit();
}
?>
