function validateForm() {
  const password = document.getElementById("password").value;
  const captchaInput = document.getElementById("captcha_input").value;
  const captchaHidden = document.getElementById("captcha_hidden").value;

  const strength = document.getElementById("strength");
  let score = 0;

  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score < 3) {
    strength.innerText = "Weak";
    strength.style.color = "red";
    return false;
  } else if (score < 5) {
    strength.innerText = "Medium";
    strength.style.color = "orange";
  } else {
    strength.innerText = "Strong";
    strength.style.color = "green";
  }

  if (captchaInput !== captchaHidden) {
    alert("Incorrect CAPTCHA.");
    return false;
  }

  return true;
}