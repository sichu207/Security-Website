<?php
session_start();
include 'db.php';
include 'session_manager.php';

// Initialize session manager
$sessionManager = new SessionManager($conn);

// Log logout if user was logged in
if (isset($_SESSION['session_id']) && isset($_SESSION['user_id'])) {
    $sessionManager->logLoginAttempt($_SESSION['user_id'], $_SESSION['email'] ?? 'unknown', 'success', 'User logged out');
    $sessionManager->destroySession($_SESSION['session_id']);
}

// Destroy PHP session
session_destroy();

// Clean expired sessions periodically
$sessionManager->cleanExpiredSessions();

header("Location: login.html");
exit();
