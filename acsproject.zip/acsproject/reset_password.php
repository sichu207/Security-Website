<?php
include 'db.php';
session_start();

$message = '';

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = ? AND reset_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['reset_user_id'] = $user['id'];
        $_SESSION['reset_token'] = $token;

        // ✅ Token valid — redirect to password reset form
        header("Location: set_new_password.php");
        exit();
    } else {
        $message = "Invalid or expired token. Please request a new reset link.";
    }

    $stmt->close();
} else {
    $message = "No reset token provided in the URL.";
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Reset Password</h2>
    <p class="message"><?php echo htmlspecialchars($message); ?></p>
    <p><a href="forgot_password.php">Request New Reset Link</a></p>
</body>
</html>
