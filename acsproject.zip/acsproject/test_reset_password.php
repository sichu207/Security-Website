<?php
// Test page for OTP-based password reset system
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Password Reset System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>🔐 OTP-Based Password Reset System</h2>
        
        <div class="step">
            <h3>Step 1: Request Password Reset</h3>
            <p>Enter your email address to receive a 6-digit OTP via email.</p>
            <a href="forgot_password.php" class="btn">Go to Forgot Password</a>
        </div>

        <div class="step">
            <h3>Step 2: Verify OTP</h3>
            <p>Enter the 6-digit OTP sent to your email address.</p>
            <a href="reset_otp_verification.php" class="btn">Verify OTP</a>
        </div>

        <div class="step">
            <h3>Step 3: Set New Password</h3>
            <p>After OTP verification, set your new password.</p>
            <a href="set_new_password.php" class="btn">Set New Password</a>
        </div>

        <div class="step">
            <h3>Database Setup</h3>
            <p>Make sure your database has the required columns. Run the SQL script:</p>
            <a href="update_database.sql" class="btn btn-success">View SQL Script</a>
        </div>

        <div class="step">
            <h3>Features:</h3>
            <ul>
                <li>✅ 6-digit OTP sent via email</li>
                <li>✅ 10-minute OTP expiration</li>
                <li>✅ Secure password hashing</li>
                <li>✅ Password confirmation</li>
                <li>✅ Modern, responsive UI</li>
                <li>✅ Auto-submit on 6 digits</li>
                <li>✅ Input validation</li>
            </ul>
        </div>

        <div class="step">
            <h3>Email Configuration</h3>
            <p>Make sure your Gmail SMTP settings are correct in <code>forgot_password.php</code>:</p>
            <ul>
                <li>Username: maharjansichu84@gmail.com</li>
                <li>Password: gyfbfspwwjmxdhda (App Password)</li>
                <li>SMTP: smtp.gmail.com:587</li>
            </ul>
        </div>
    </div>
</body>
</html> 