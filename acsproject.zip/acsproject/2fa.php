<?php session_start(); if (!isset($_SESSION['pending_2fa_user'])) { header("Location: login.html"); exit(); } ?>
<!DOCTYPE html>
<html>
<head>
  <title>2FA Verification</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>2FA Verification</h2>
    <form action="2fa_verify.php" method="POST">
      <label for="code">Enter 2FA Code:</label>
      <input type="text" name="code" id="code" required pattern="\d{6}" maxlength="6" />
      <input type="submit" value="Verify">
    </form>
  </div>
</body>
</html>
