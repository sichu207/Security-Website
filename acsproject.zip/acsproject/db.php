<?php
$servername = "localhost";
$username = "root";      // your DB username
$password = "";          // your DB password (empty by default in XAMPP)
$dbname = "acs";         // your database name

// Create connection
$conn = new mysqli($servername, 'root', $password, 'acs');

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}
?>
