<?php
header("Content-Type: image/png");

$width = 150;
$height = 50;
$image = imagecreatetruecolor($width, $height);

$bg_color = imagecolorallocate($image, 255, 204, 255); // light pink background
$text_color = imagecolorallocate($image, 0, 0, 0);

imagefilledrectangle($image, 0, 0, $width, $height, $bg_color);

imagestring($image, 5, 50, 15, "TEST", $text_color);

imagepng($image);
imagedestroy($image);
?>
