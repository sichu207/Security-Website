<?php
session_start();
include 'db.php';
include 'session_manager.php';
include 'password_policy_manager.php';

// Initialize session manager
$sessionManager = new SessionManager($conn);
$passwordPolicy = new PasswordPolicyManager($conn);

// Check if user is logged in
if (!isset($_SESSION['username']) || !isset($_SESSION['session_id'])) {
    header("Location: login.html");
    exit();
}

// Validate session in database
$session_data = $sessionManager->validateSession($_SESSION['session_id']);
if (!$session_data) {
    // Session is invalid or expired
    session_destroy();
    header("Location: login.html?error=" . urlencode('Session expired. Please login again.'));
    exit();
}

// Get user's active sessions and login history
$active_sessions = $sessionManager->getUserSessions($_SESSION['user_id']);
$login_history = $sessionManager->getLoginHistory($_SESSION['user_id'], 5);

// Get password policy information
$expiry_info = $passwordPolicy->getPasswordExpiryInfo($_SESSION['user_id']);
$lockout_info = $passwordPolicy->getAccountLockoutInfo($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard - Job Portal</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <!-- Navigation Header -->
  <nav class="navbar">
    <div class="nav-container">
      <div class="nav-brand">
        <i class="fas fa-briefcase"></i>
        <span>Job Portal</span>
      </div>
      <div class="nav-menu">
        <a href="#dashboard" class="nav-link active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="#jobs" class="nav-link"><i class="fas fa-search"></i> Find Jobs</a>
        <a href="#applications" class="nav-link"><i class="fas fa-file-alt"></i> Applications</a>
        <a href="#profile" class="nav-link"><i class="fas fa-user"></i> Profile</a>
        <a href="#security" class="nav-link"><i class="fas fa-shield-alt"></i> Security</a>
        <div class="nav-user">
          <span class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
          <a href="logout.php" class="logout-btn-small"><i class="fas fa-sign-out-alt"></i></a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
      <div class="welcome-card">
        <div class="welcome-icon">
          <i class="fas fa-user-tie"></i>
        </div>
        <div class="welcome-text">
          <h1>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
          <p>Your job search dashboard is ready. Find your next career opportunity.</p>
        </div>
        <div class="welcome-time">
          <div class="time-display">
            <i class="fas fa-clock"></i>
            <span id="current-time"></span>
          </div>
        </div>
      </div>
    </div>

    <!-- Dashboard Grid -->
    <div class="dashboard-grid">
      <!-- Job Search Card -->
      <div class="dashboard-card job-search-card" id="jobs">
        <div class="card-header">
          <i class="fas fa-search"></i>
          <h3>Job Search</h3>
        </div>
        <div class="card-content">
          <div class="job-stats">
            <div class="stat-item">
              <div class="stat-icon">
                <i class="fas fa-briefcase"></i>
              </div>
              <div class="stat-details">
                <h4>Available Jobs</h4>
                <p class="stat-number">1,247</p>
                <small>New jobs posted today</small>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon">
                <i class="fas fa-map-marker-alt"></i>
              </div>
              <div class="stat-details">
                <h4>Your Location</h4>
                <p class="stat-text">Remote & Local</p>
                <small>Based on your preferences</small>
              </div>
            </div>
          </div>
          <div class="card-actions">
            <a href="#search-jobs" class="btn btn-primary">
              <i class="fas fa-search"></i> Search Jobs
            </a>
            <a href="#saved-jobs" class="btn btn-secondary">
              <i class="fas fa-bookmark"></i> Saved Jobs
            </a>
          </div>
        </div>
      </div>

      <!-- Applications Card -->
      <div class="dashboard-card applications-card" id="applications">
        <div class="card-header">
          <i class="fas fa-file-alt"></i>
          <h3>My Applications</h3>
        </div>
        <div class="card-content">
          <div class="application-stats">
            <div class="stat-item">
              <div class="stat-icon success">
                <i class="fas fa-paper-plane"></i>
              </div>
              <div class="stat-details">
                <h4>Submitted</h4>
                <p class="stat-number">12</p>
                <small>Applications sent</small>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon warning">
                <i class="fas fa-clock"></i>
              </div>
              <div class="stat-details">
                <h4>Pending</h4>
                <p class="stat-number">8</p>
                <small>Under review</small>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon danger">
                <i class="fas fa-times"></i>
              </div>
              <div class="stat-details">
                <h4>Rejected</h4>
                <p class="stat-number">3</p>
                <small>Not selected</small>
              </div>
            </div>
          </div>
          <div class="card-actions">
            <a href="#view-applications" class="btn btn-primary">
              <i class="fas fa-eye"></i> View All
            </a>
          </div>
        </div>
      </div>

      <!-- Profile Card -->
      <div class="dashboard-card profile-card" id="profile">
        <div class="card-header">
          <i class="fas fa-user"></i>
          <h3>Profile Status</h3>
        </div>
        <div class="card-content">
          <div class="profile-completion">
            <div class="completion-bar">
              <div class="completion-fill" style="width: 85%;"></div>
            </div>
            <p class="completion-text">Profile 85% Complete</p>
          </div>
          <div class="profile-items">
            <div class="profile-item">
              <i class="fas fa-check-circle success"></i>
              <span>Basic Information</span>
            </div>
            <div class="profile-item">
              <i class="fas fa-check-circle success"></i>
              <span>Resume Uploaded</span>
            </div>
            <div class="profile-item">
              <i class="fas fa-exclamation-circle warning"></i>
              <span>Skills & Certifications</span>
            </div>
            <div class="profile-item">
              <i class="fas fa-times-circle danger"></i>
              <span>Portfolio</span>
            </div>
          </div>
          <div class="card-actions">
            <a href="#edit-profile" class="btn btn-primary">
              <i class="fas fa-edit"></i> Complete Profile
            </a>
          </div>
        </div>
      </div>

      <!-- Security Status Card -->
      <div class="dashboard-card security-card" id="security">
        <div class="card-header">
          <i class="fas fa-shield-alt"></i>
          <h3>Account Security</h3>
        </div>
        <div class="card-content">
          <?php if ($expiry_info): ?>
            <div class="status-item">
              <div class="status-icon <?php echo $expiry_info['is_expired'] ? 'danger' : ($expiry_info['is_expiring_soon'] ? 'warning' : 'success'); ?>">
                <i class="fas fa-key"></i>
              </div>
              <div class="status-details">
                <h4>Password Status</h4>
                <?php if ($expiry_info['is_expired']): ?>
                  <p class="status-text danger">Password Expired</p>
                  <small>Last changed: <?php echo htmlspecialchars($expiry_info['changed_at']); ?></small>
                <?php elseif ($expiry_info['is_expiring_soon']): ?>
                  <p class="status-text warning">Expires in <?php echo $expiry_info['days_until_expiry']; ?> days</p>
                  <small>Expires: <?php echo htmlspecialchars($expiry_info['expires_at']); ?></small>
                <?php else: ?>
                  <p class="status-text success">Valid for <?php echo $expiry_info['days_until_expiry']; ?> days</p>
                  <small>Expires: <?php echo htmlspecialchars($expiry_info['expires_at']); ?></small>
                <?php endif; ?>
              </div>
            </div>
          <?php endif; ?>
          
          <?php if ($lockout_info): ?>
            <div class="status-item">
              <div class="status-icon <?php echo $lockout_info['remaining_attempts'] <= 2 ? 'warning' : 'success'; ?>">
                <i class="fas fa-lock"></i>
              </div>
              <div class="status-details">
                <h4>Login Security</h4>
                <p class="status-text"><?php echo $lockout_info['remaining_attempts']; ?> attempts remaining</p>
                <small><?php echo $lockout_info['failed_attempts']; ?> failed attempts</small>
              </div>
            </div>
          <?php endif; ?>
          
          <div class="card-actions">
            <a href="change_password.php" class="btn btn-primary">
              <i class="fas fa-edit"></i> Change Password
            </a>
            <?php if ($expiry_info && $expiry_info['is_expired']): ?>
              <span class="alert-badge danger">⚠️ Password expired!</span>
            <?php elseif ($expiry_info && $expiry_info['is_expiring_soon']): ?>
              <span class="alert-badge warning">⚠️ Expiring soon</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Current Session Card -->
      <div class="dashboard-card session-card">
        <div class="card-header">
          <i class="fas fa-desktop"></i>
          <h3>Active Session</h3>
        </div>
        <div class="card-content">
          <div class="session-details">
            <div class="detail-item">
              <i class="fas fa-fingerprint"></i>
              <span>Session ID: <?php echo substr($_SESSION['session_id'], 0, 16) . '...'; ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-globe"></i>
              <span>IP: <?php echo htmlspecialchars($session_data['ip_address']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-sign-in-alt"></i>
              <span>Login: <?php echo htmlspecialchars($session_data['created_at']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-clock"></i>
              <span>Last Activity: <?php echo htmlspecialchars($session_data['last_activity']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-hourglass-end"></i>
              <span>Expires: <?php echo htmlspecialchars($session_data['expires_at']); ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Activity Card -->
      <div class="dashboard-card activity-card">
        <div class="card-header">
          <i class="fas fa-history"></i>
          <h3>Recent Activity</h3>
        </div>
        <div class="card-content">
          <?php if (!empty($login_history)): ?>
            <div class="activity-list">
              <?php foreach (array_slice($login_history, 0, 3) as $login): ?>
                <div class="activity-item <?php echo $login['status']; ?>">
                  <div class="activity-icon">
                    <i class="fas fa-<?php echo $login['status'] === 'success' ? 'sign-in-alt' : 'exclamation-triangle'; ?>"></i>
                  </div>
                  <div class="activity-details">
                    <div class="activity-time"><?php echo htmlspecialchars($login['login_time']); ?></div>
                    <div class="activity-desc"><?php echo ucfirst($login['status']); ?> login from <?php echo htmlspecialchars($login['ip_address']); ?></div>
                  </div>
                  <div class="activity-status">
                    <span class="status-badge <?php echo $login['status']; ?>">
                      <?php echo ucfirst($login['status']); ?>
                    </span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="empty-state">
              <i class="fas fa-info-circle"></i>
              <p>No recent activity found.</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="dashboard-footer">
      <div class="footer-content">
        <p>&copy; 2024 Job Portal. All rights reserved.</p>
        <div class="footer-links">
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
          <a href="#support">Support</a>
        </div>
      </div>
    </footer>
  </div>

  <script>
    // Update current time
    function updateTime() {
      const now = new Date();
      const timeString = now.toLocaleString();
      document.getElementById('current-time').textContent = timeString;
    }
    
    updateTime();
    setInterval(updateTime, 1000);

    // Smooth scrolling for navigation
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth' });
        }
        
        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
      });
    });
  </script>
</body>
</html> 