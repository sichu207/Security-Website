<?php
include 'db.php';
session_start();

$message = '';
$success_message = '';

// Check if email is in session
if (!isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit();
}

$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = trim((string)($_POST['otp'] ?? ''));
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate OTP
    $stmt = $conn->prepare("SELECT id, reset_token, reset_expiry FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    $now = date('Y-m-d H:i:s');
    $db_otp = isset($user['reset_token']) ? trim((string)$user['reset_token']) : '';
    $db_expiry = $user['reset_expiry'] ?? '';

    // Debug log
    error_log("[RESET OTP] Email: $email | Entered OTP: '$otp' | DB OTP: '$db_otp' | Expiry: $db_expiry | Now: $now");

    if (!$user || !$db_otp) {
        $message = "No OTP found for this email. Please request a new one.";
    } elseif ($db_expiry < $now) {
        $message = "OTP has expired. Please request a new one.";
    } elseif ($db_otp !== $otp) {
        $message = "Invalid OTP. Please check your email and try again.";
    } elseif (strlen($new_password) < 6) {
        $message = "Password must be at least 6 characters.";
    } elseif ($new_password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        // All good, update password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $user['id']);
        $stmt->execute();
        $stmt->close();
        unset($_SESSION['reset_email']);
        $success_message = "✅ Password updated successfully! <form action='login.html' style='margin:0;display:inline;'><button type='submit' class='small-btn' style='width:auto;display:inline-block;margin-left:10px;'>Login here</button></form>";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password with OTP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>🔐 Reset Password</h2>
        <div class="info">
            <strong>Password Reset OTP Sent!</strong><br>
            We've sent a 6-digit OTP to: <strong><?php echo htmlspecialchars($email); ?></strong><br>
            Please check your inbox and enter the OTP and your new password below.
        </div>
        <?php if ($message): ?>
            <div class="error"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <div class="success"><?php echo $success_message; ?></div>
        <?php else: ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="otp"><strong>Enter Reset OTP:</strong></label>
                <input type="text" id="otp" name="otp" class="otp-input" required placeholder="000000" maxlength="6" pattern="[0-9]{6}" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);">
            </div>
            <div class="form-group">
                <label for="new_password"><strong>New Password:</strong></label>
                <input type="password" id="new_password" name="new_password" required minlength="6" placeholder="Enter new password">
            </div>
            <div class="form-group">
                <label for="confirm_password"><strong>Confirm Password:</strong></label>
                <input type="password" id="confirm_password" name="confirm_password" required minlength="6" placeholder="Confirm new password">
            </div>
            <input type="submit" value="Reset Password" class="submit-btn">
        </form>
        <?php endif; ?>
        <div class="back-link">
            <a href="forgot_password.php">← Back to Forgot Password</a>
        </div>
    </div>
    <script>
        document.getElementById('otp')?.focus();
        document.getElementById('confirm_password')?.addEventListener('input', function() {
            const password = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            if (password !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html> 