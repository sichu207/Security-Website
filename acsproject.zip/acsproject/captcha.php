<?php
session_start();

$captcha_text = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"), 0, 6);
$_SESSION['captcha'] = $captcha_text;

$width = 150;
$height = 50;

$image = imagecreatetruecolor($width, $height);

// Colors
$bg_color = imagecolorallocate($image, 255, 204, 255); // light pink background
$text_color = imagecolorallocate($image, 0, 0, 0);
$line_color = imagecolorallocate($image, 200, 100, 200);

// Fill background
imagefilledrectangle($image, 0, 0, $width, $height, $bg_color);

// Draw noise lines
for ($i = 0; $i < 5; $i++) {
    imageline($image, 0, rand(0, $height), $width, rand(0, $height), $line_color);
}

// Calculate text position
$font = 5;
$text_box_width = imagefontwidth($font) * strlen($captcha_text);
$text_box_height = imagefontheight($font);
$x = ($width - $text_box_width) / 2;
$y = ($height - $text_box_height) / 2;

// Draw the CAPTCHA text
imagestring($image, $font, $x, $y, $captcha_text, $text_color);

// Output the image
header("Content-Type: image/png");
imagepng($image);
imagedestroy($image);
exit();
?>
