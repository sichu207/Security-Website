<?php
session_start();
include 'db.php';
include 'session_manager.php'; // Include session manager

// Initialize session manager
$sessionManager = new SessionManager($conn);

$message = '';

// Check if temp_user is in session (from login)
if (!isset($_SESSION['temp_user'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_otp = trim($_POST['otp']);
    $userId = $_SESSION['temp_user']['id'] ?? null;

    if ($userId) {
        $stmt = $conn->prepare("SELECT otp, otp_expiry, username, email FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $storedOtp = $row['otp'];
            $otpExpiry = $row['otp_expiry'];
            $username = $row['username'];
            $email = $row['email'];
            $currentDateTime = date("Y-m-d H:i:s");

            if ($entered_otp === $storedOtp && $currentDateTime <= $otpExpiry) {
                // ✅ OTP is valid - Create session
                $session_id = $sessionManager->createSession($userId);
                
                // Set session variables
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                $_SESSION['user_id'] = $userId;
                $_SESSION['session_id'] = $session_id;

                // Log successful login completion
                $sessionManager->logLoginAttempt($userId, $email, 'success', 'OTP verified successfully');

                unset($_SESSION['temp_user']);

                header("Location: dashboard.php");
                exit();
            } else {
                // Log failed OTP attempt
                $sessionManager->logLoginAttempt($userId, $email, 'failure', 'Invalid or expired OTP');
                $message = "Invalid or expired OTP.";
            }
        } else {
            $message = "User not found.";
        }
    } else {
        $message = "Session expired. Please login again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login OTP Verification</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Enter Login OTP</h2>
        <form action="otp_verification.php" method="POST">
            <div class="otp-input-group">
                <label for="otp">OTP:</label>
                <input type="text" id="otp" name="otp" maxlength="6" required>
            </div>

            <?php if (!empty($message)) : ?>
                <div class="error-message" style="color:red; margin: 10px 0;">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <input type="submit" value="Verify OTP">
        </form>
    </div>
</body>
</html>
