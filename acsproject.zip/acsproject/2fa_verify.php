<?php
session_start();
include 'db.php';
require_once 'GoogleAuthenticator.php';

if (!isset($_SESSION['pending_2fa_user'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['pending_2fa_user'];
$code = $_POST['code'];

// Fetch 2FA secret
$stmt = $conn->prepare("SELECT username, twofa_secret FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$ga = new PHPGangsta_GoogleAuthenticator();
$isValid = $ga->verifyCode($user['twofa_secret'], $code, 2); // 2 = 1 min window

if ($isValid) {
    $_SESSION['username'] = $user['username'];  // full login
    unset($_SESSION['pending_2fa_user']);
    header("Location: dashboard.php");
    exit();
} else {
    echo "<p style='color:red;'>Invalid 2FA Code. <a href='2fa.php'>Try Again</a></p>";
}
?>
