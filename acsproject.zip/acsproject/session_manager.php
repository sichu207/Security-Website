<?php
class SessionManager {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Get client IP address
    private function getClientIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
    
    // Get user agent
    private function getUserAgent() {
        return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }
    
    // Log login attempt
    public function logLoginAttempt($user_id, $email, $status, $reason = null) {
        $ip = $this->getClientIP();
        $login_time = date('Y-m-d H:i:s');
        
        $stmt = $this->conn->prepare("INSERT INTO login_logs (user_id, email, login_time, ip_address, status, reason) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $user_id, $email, $login_time, $ip, $status, $reason);
        $stmt->execute();
        $stmt->close();
    }
    
    // Create new session
    public function createSession($user_id) {
        $session_id = bin2hex(random_bytes(32));
        $ip = $this->getClientIP();
        $user_agent = $this->getUserAgent();
        $created_at = date('Y-m-d H:i:s');
        $last_activity = $created_at;
        $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours')); // 24 hour session
        
        $stmt = $this->conn->prepare("INSERT INTO user_sessions (user_id, session_id, ip_address, user_agent, created_at, last_activity, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $user_id, $session_id, $ip, $user_agent, $created_at, $last_activity, $expires_at);
        $stmt->execute();
        $stmt->close();
        
        // Update user's last login and login count
        $this->updateUserLoginStats($user_id);
        
        return $session_id;
    }
    
    // Update user login statistics
    private function updateUserLoginStats($user_id) {
        $last_login = date('Y-m-d H:i:s');
        $stmt = $this->conn->prepare("UPDATE users SET last_login = ?, login_count = login_count + 1 WHERE id = ?");
        $stmt->bind_param("si", $last_login, $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Validate session
    public function validateSession($session_id) {
        $current_time = date('Y-m-d H:i:s');
        
        $stmt = $this->conn->prepare("SELECT us.*, u.username, u.email FROM user_sessions us 
                                     JOIN users u ON us.user_id = u.id 
                                     WHERE us.session_id = ? AND us.is_active = 1 AND us.expires_at > ?");
        $stmt->bind_param("ss", $session_id, $current_time);
        $stmt->execute();
        $result = $stmt->get_result();
        $session = $result->fetch_assoc();
        $stmt->close();
        
        if ($session) {
            // Update last activity
            $this->updateLastActivity($session_id);
            return $session;
        }
        
        return false;
    }
    
    // Update last activity
    private function updateLastActivity($session_id) {
        $last_activity = date('Y-m-d H:i:s');
        $stmt = $this->conn->prepare("UPDATE user_sessions SET last_activity = ? WHERE session_id = ?");
        $stmt->bind_param("ss", $last_activity, $session_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Destroy session
    public function destroySession($session_id) {
        $stmt = $this->conn->prepare("UPDATE user_sessions SET is_active = 0 WHERE session_id = ?");
        $stmt->bind_param("s", $session_id);
        $stmt->execute();
        $stmt->close();
    }
    
    // Clean expired sessions
    public function cleanExpiredSessions() {
        $current_time = date('Y-m-d H:i:s');
        $stmt = $this->conn->prepare("UPDATE user_sessions SET is_active = 0 WHERE expires_at < ?");
        $stmt->bind_param("s", $current_time);
        $stmt->execute();
        $stmt->close();
    }
    
    // Get user's active sessions
    public function getUserSessions($user_id) {
        $current_time = date('Y-m-d H:i:s');
        
        $stmt = $this->conn->prepare("SELECT * FROM user_sessions WHERE user_id = ? AND is_active = 1 AND expires_at > ? ORDER BY created_at DESC");
        $stmt->bind_param("is", $user_id, $current_time);
        $stmt->execute();
        $result = $stmt->get_result();
        $sessions = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $sessions;
    }
    
    // Get login history for a user
    public function getLoginHistory($user_id, $limit = 10) {
        $stmt = $this->conn->prepare("SELECT * FROM login_logs WHERE user_id = ? ORDER BY login_time DESC LIMIT ?");
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $history = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $history;
    }
}
?> 