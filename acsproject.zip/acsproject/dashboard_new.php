<?php
session_start();
include 'db.php';
include 'session_manager.php';
include 'password_policy_manager.php';

// Initialize session manager
$sessionManager = new SessionManager($conn);
$passwordPolicy = new PasswordPolicyManager($conn);

// Check if user is logged in
if (!isset($_SESSION['username']) || !isset($_SESSION['session_id'])) {
    header("Location: login.html");
    exit();
}

// Validate session in database
$session_data = $sessionManager->validateSession($_SESSION['session_id']);
if (!$session_data) {
    // Session is invalid or expired
    session_destroy();
    header("Location: login.html?error=" . urlencode('Session expired. Please login again.'));
    exit();
}

// Get user's active sessions and login history
$active_sessions = $sessionManager->getUserSessions($_SESSION['user_id']);
$login_history = $sessionManager->getLoginHistory($_SESSION['user_id'], 5);

// Get password policy information
$expiry_info = $passwordPolicy->getPasswordExpiryInfo($_SESSION['user_id']);
$lockout_info = $passwordPolicy->getAccountLockoutInfo($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard - Secure Portal</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <!-- Navigation Header -->
  <nav class="navbar">
    <div class="nav-container">
      <div class="nav-brand">
        <i class="fas fa-shield-alt"></i>
        <span>Secure Portal</span>
      </div>
      <div class="nav-menu">
        <a href="#dashboard" class="nav-link active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="#security" class="nav-link"><i class="fas fa-lock"></i> Security</a>
        <a href="#sessions" class="nav-link"><i class="fas fa-users"></i> Sessions</a>
        <a href="#history" class="nav-link"><i class="fas fa-history"></i> History</a>
        <div class="nav-user">
          <span class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
          <a href="logout.php" class="logout-btn-small"><i class="fas fa-sign-out-alt"></i></a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
      <div class="welcome-card">
        <div class="welcome-icon">
          <i class="fas fa-user-circle"></i>
        </div>
        <div class="welcome-text">
          <h1>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
          <p>Your secure dashboard is ready. Here's what's happening with your account.</p>
        </div>
        <div class="welcome-time">
          <div class="time-display">
            <i class="fas fa-clock"></i>
            <span id="current-time"></span>
          </div>
        </div>
      </div>
    </div>

    <!-- Dashboard Grid -->
    <div class="dashboard-grid">
      <!-- Security Status Card -->
      <div class="dashboard-card security-card" id="security">
        <div class="card-header">
          <i class="fas fa-shield-alt"></i>
          <h3>Security Status</h3>
        </div>
        <div class="card-content">
          <?php if ($expiry_info): ?>
            <div class="status-item">
              <div class="status-icon <?php echo $expiry_info['is_expired'] ? 'danger' : ($expiry_info['is_expiring_soon'] ? 'warning' : 'success'); ?>">
                <i class="fas fa-key"></i>
              </div>
              <div class="status-details">
                <h4>Password Status</h4>
                <?php if ($expiry_info['is_expired']): ?>
                  <p class="status-text danger">Password Expired</p>
                  <small>Last changed: <?php echo htmlspecialchars($expiry_info['changed_at']); ?></small>
                <?php elseif ($expiry_info['is_expiring_soon']): ?>
                  <p class="status-text warning">Expires in <?php echo $expiry_info['days_until_expiry']; ?> days</p>
                  <small>Expires: <?php echo htmlspecialchars($expiry_info['expires_at']); ?></small>
                <?php else: ?>
                  <p class="status-text success">Valid for <?php echo $expiry_info['days_until_expiry']; ?> days</p>
                  <small>Expires: <?php echo htmlspecialchars($expiry_info['expires_at']); ?></small>
                <?php endif; ?>
              </div>
            </div>
          <?php endif; ?>
          
          <?php if ($lockout_info): ?>
            <div class="status-item">
              <div class="status-icon <?php echo $lockout_info['remaining_attempts'] <= 2 ? 'warning' : 'success'; ?>">
                <i class="fas fa-lock"></i>
              </div>
              <div class="status-details">
                <h4>Login Attempts</h4>
                <p class="status-text"><?php echo $lockout_info['remaining_attempts']; ?> attempts remaining</p>
                <small><?php echo $lockout_info['failed_attempts']; ?> failed attempts</small>
              </div>
            </div>
          <?php endif; ?>
          
          <div class="card-actions">
            <a href="change_password.php" class="btn btn-primary">
              <i class="fas fa-edit"></i> Change Password
            </a>
            <?php if ($expiry_info && $expiry_info['is_expired']): ?>
              <span class="alert-badge danger">⚠️ Password expired!</span>
            <?php elseif ($expiry_info && $expiry_info['is_expiring_soon']): ?>
              <span class="alert-badge warning">⚠️ Expiring soon</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Current Session Card -->
      <div class="dashboard-card session-card" id="sessions">
        <div class="card-header">
          <i class="fas fa-desktop"></i>
          <h3>Current Session</h3>
        </div>
        <div class="card-content">
          <div class="session-details">
            <div class="detail-item">
              <i class="fas fa-fingerprint"></i>
              <span>Session ID: <?php echo substr($_SESSION['session_id'], 0, 16) . '...'; ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-globe"></i>
              <span>IP: <?php echo htmlspecialchars($session_data['ip_address']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-sign-in-alt"></i>
              <span>Login: <?php echo htmlspecialchars($session_data['created_at']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-clock"></i>
              <span>Last Activity: <?php echo htmlspecialchars($session_data['last_activity']); ?></span>
            </div>
            <div class="detail-item">
              <i class="fas fa-hourglass-end"></i>
              <span>Expires: <?php echo htmlspecialchars($session_data['expires_at']); ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Active Sessions Card -->
      <div class="dashboard-card sessions-list-card">
        <div class="card-header">
          <i class="fas fa-users"></i>
          <h3>Active Sessions (<?php echo count($active_sessions); ?>)</h3>
        </div>
        <div class="card-content">
          <?php if (!empty($active_sessions)): ?>
            <div class="sessions-list">
              <?php foreach ($active_sessions as $session): ?>
                <div class="session-item <?php echo $session['session_id'] === $_SESSION['session_id'] ? 'current' : ''; ?>">
                  <div class="session-icon">
                    <i class="fas fa-desktop"></i>
                  </div>
                  <div class="session-info">
                    <div class="session-ip"><?php echo htmlspecialchars($session['ip_address']); ?></div>
                    <div class="session-time"><?php echo htmlspecialchars($session['created_at']); ?></div>
                  </div>
                  <?php if ($session['session_id'] === $_SESSION['session_id']): ?>
                    <span class="current-badge">Current</span>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="empty-state">
              <i class="fas fa-info-circle"></i>
              <p>No active sessions found.</p>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Login History Card -->
      <div class="dashboard-card history-card" id="history">
        <div class="card-header">
          <i class="fas fa-history"></i>
          <h3>Recent Login History</h3>
        </div>
        <div class="card-content">
          <?php if (!empty($login_history)): ?>
            <div class="history-list">
              <?php foreach ($login_history as $login): ?>
                <div class="history-item <?php echo $login['status']; ?>">
                  <div class="history-icon">
                    <i class="fas fa-<?php echo $login['status'] === 'success' ? 'check-circle' : 'times-circle'; ?>"></i>
                  </div>
                  <div class="history-details">
                    <div class="history-time"><?php echo htmlspecialchars($login['login_time']); ?></div>
                    <div class="history-ip"><?php echo htmlspecialchars($login['ip_address']); ?></div>
                    <?php if ($login['reason']): ?>
                      <div class="history-reason"><?php echo htmlspecialchars($login['reason']); ?></div>
                    <?php endif; ?>
                  </div>
                  <div class="history-status">
                    <span class="status-badge <?php echo $login['status']; ?>">
                      <?php echo ucfirst($login['status']); ?>
                    </span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="empty-state">
              <i class="fas fa-info-circle"></i>
              <p>No login history found.</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="dashboard-footer">
      <div class="footer-content">
        <p>&copy; 2024 Secure Portal. All rights reserved.</p>
        <div class="footer-links">
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
          <a href="#support">Support</a>
        </div>
      </div>
    </footer>
  </div>

  <script>
    // Update current time
    function updateTime() {
      const now = new Date();
      const timeString = now.toLocaleString();
      document.getElementById('current-time').textContent = timeString;
    }
    
    updateTime();
    setInterval(updateTime, 1000);

    // Smooth scrolling for navigation
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth' });
        }
        
        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
      });
    });
  </script>
</body>
</html> 