<?php
session_start();

$servername = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "acs";

$conn = new mysqli($servername, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = htmlspecialchars(trim($_POST['fullname']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $username = htmlspecialchars(trim($_POST['username']));
    $password = $_POST['password'];
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // Verify reCAPTCHA v2
    $secretKey = "6LeTJ2orAAAAAKtK3Us_eKpCjSthFQnMpiCelFPX";
    $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptchaResponse");
    $captchaSuccess = json_decode($verify);

    if (!$captchaSuccess || !$captchaSuccess->success) {
        echo "<h3 style='color:red;text-align:center;'>reCAPTCHA verification failed.</h3>";
        echo "<p style='text-align:center;'><a href='register.html'>Go back</a></p>";
        exit();
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<h3 style='color:red;text-align:center;'>Invalid email format.</h3>";
        exit();
    }

    // Validate password length
    if (strlen($password) < 8) {
        echo "<h3 style='color:red;text-align:center;'>Password must be at least 8 characters long.</h3>";
        exit();
    }

    // Check duplicate username or email
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<h3 style='color:red;text-align:center;'>Username or Email already exists.</h3>";
        echo "<p style='text-align:center;'><a href='register.html'>Go back</a></p>";
        $stmt->close();
        exit();
    }
    $stmt->close();

    // Hash password securely
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert new user (no 2FA secret initially)
    $stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, username, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $fullname, $email, $phone, $username, $hashed_password);

    if ($stmt->execute()) {
        header("Location: login.html");
        exit();
    } else {
        error_log("Registration failed: " . $stmt->error);
        echo "<h3 style='color:red;text-align:center;'>Registration failed. Please try again.</h3>";
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: register.html");
    exit();
}
?>
