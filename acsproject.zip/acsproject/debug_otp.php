<?php
include 'db.php';
session_start();

// Check if user is logged in or has reset session
$email = $_SESSION['reset_email'] ?? '';

if ($email) {
    $stmt = $conn->prepare("SELECT id, email, reset_token, reset_expiry FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_data = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>OTP Debug Info</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>🔍 OTP Debug Information</h2>
    
    <div class="debug-info">
        <h3>Session Information:</h3>
        <p><strong>Reset Email:</strong> <?php echo htmlspecialchars($email ?: 'Not set'); ?></p>
        <p><strong>Reset User ID:</strong> <?php echo $_SESSION['reset_user_id'] ?? 'Not set'; ?></p>
        <p><strong>Reset Verified:</strong> <?php echo isset($_SESSION['reset_verified']) ? 'Yes' : 'No'; ?></p>
    </div>

    <?php if ($email && $user_data): ?>
        <div class="debug-info">
            <h3>Database Information:</h3>
            <p><strong>User ID:</strong> <?php echo $user_data['id']; ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user_data['email']); ?></p>
            <p><strong>Reset Token (OTP):</strong> <?php echo htmlspecialchars($user_data['reset_token'] ?: 'NULL'); ?></p>
            <p><strong>Reset Expiry:</strong> <?php echo htmlspecialchars($user_data['reset_expiry'] ?: 'NULL'); ?></p>
            <p><strong>Current Time:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
            <p><strong>Is Expired:</strong> 
                <?php 
                if ($user_data['reset_expiry']) {
                    $is_expired = date('Y-m-d H:i:s') > $user_data['reset_expiry'];
                    echo $is_expired ? '<span class="error">YES</span>' : '<span class="success">NO</span>';
                } else {
                    echo 'N/A';
                }
                ?>
            </p>
        </div>
    <?php elseif ($email): ?>
        <div class="debug-info error">
            <h3>Error:</h3>
            <p>User with email "<?php echo htmlspecialchars($email); ?>" not found in database.</p>
        </div>
    <?php else: ?>
        <div class="debug-info">
            <h3>No Reset Session:</h3>
            <p>No password reset session found. Please start the password reset process.</p>
            <p><a href="forgot_password.php">Go to Forgot Password</a></p>
        </div>
    <?php endif; ?>

    <div class="debug-info">
        <h3>Actions:</h3>
        <p><a href="forgot_password.php">Start Password Reset</a></p>
        <p><a href="reset_otp_verification.php">Go to OTP Verification</a></p>
        <p><a href="test_reset_password.php">Test Reset System</a></p>
    </div>
</body>
</html> 