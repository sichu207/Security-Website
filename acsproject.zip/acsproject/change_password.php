<?php
session_start();
include 'db.php';
include 'session_manager.php';
include 'password_policy_manager.php';

// Initialize managers
$sessionManager = new SessionManager($conn);
$passwordPolicy = new PasswordPolicyManager($conn);

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || !isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate current password
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if (!password_verify($current_password, $user['password'])) {
        $error = "Current password is incorrect.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match.";
    } else {
        // Validate new password against policy
        $validation_errors = $passwordPolicy->validatePassword($new_password, $user_id);
        
        if (!empty($validation_errors)) {
            $error = implode(" ", $validation_errors);
        } else {
            // Update password
            if ($passwordPolicy->updatePassword($user_id, $new_password)) {
                $message = "Password changed successfully!";
                
                // Log password change
                $sessionManager->logLoginAttempt($user_id, $_SESSION['email'] ?? 'unknown', 'success', 'Password changed successfully');
            } else {
                $error = "Failed to update password. Please try again.";
            }
        }
    }
}

// Get password expiry information
$expiry_info = $passwordPolicy->getPasswordExpiryInfo($user_id);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Change Password</h2>
        
        <?php if ($message): ?>
            <div class="success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <!-- Password expiry warning -->
        <?php if ($expiry_info && $expiry_info['is_expiring_soon']): ?>
            <div class="info">
                ⚠️ Your password will expire in <?php echo $expiry_info['days_until_expiry']; ?> days.
            </div>
        <?php endif; ?>
        
        <?php if ($expiry_info && $expiry_info['is_expired']): ?>
            <div class="error">
                ⚠️ Your password has expired. Please change it now.
            </div>
        <?php endif; ?>
        
        <form action="change_password.php" method="POST" id="changePasswordForm">
            <label for="current_password">Current Password:</label>
            <input type="password" id="current_password" name="current_password" required>
            
            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required>
            <div id="strength" class="strength"></div>
            <ul id="feedback" class="feedback-list"></ul>
            
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            
            <input type="submit" value="Change Password" class="btn">
        </form>
        
        <div style="margin-top: 20px;">
            <a href="dashboard.php" class="btn" style="text-decoration: none; text-align: center;">Back to Dashboard</a>
        </div>
    </div>

    <script>
        const passwordInput = document.getElementById('new_password');
        const confirmInput = document.getElementById('confirm_password');
        const strengthDiv = document.getElementById('strength');
        const feedbackList = document.getElementById('feedback');

        const commonPasswords = [
            '123456', 'password', '12345678', 'qwerty', 'abc123',
            '111111', '123123', 'password1', '123456789', 'admin',
            'letmein', 'welcome', 'monkey', '1234567', '1234567890'
        ];

        passwordInput.addEventListener('input', () => {
            const pwd = passwordInput.value;
            const feedback = [];
            let score = 0;

            if (pwd.length >= 8) score++;
            else feedback.push("Minimum 8 characters");

            if (/[A-Z]/.test(pwd)) score++;
            else feedback.push("Add uppercase letter");

            if (/[a-z]/.test(pwd)) score++;
            else feedback.push("Add lowercase letter");

            if (/\d/.test(pwd)) score++;
            else feedback.push("Add a number");

            if (/[^A-Za-z0-9]/.test(pwd)) score++;
            else feedback.push("Add a special character");

            if (!commonPasswords.includes(pwd.toLowerCase())) score++;
            else feedback.push("Avoid common passwords");

            // Update strength display
            if (pwd.length === 0) {
                strengthDiv.textContent = "";
                strengthDiv.style.color = "";
            } else if (score <= 2) {
                strengthDiv.textContent = "Strength: Weak";
                strengthDiv.style.color = "#e91e63";
            } else if (score <= 4) {
                strengthDiv.textContent = "Strength: Medium";
                strengthDiv.style.color = "#ff9800";
            } else {
                strengthDiv.textContent = "Strength: Strong";
                strengthDiv.style.color = "#38d39f";
            }

            // Update feedback list
            feedbackList.innerHTML = "";
            feedback.forEach(msg => {
                const li = document.createElement("li");
                li.textContent = msg;
                li.style.color = "#e91e63";
                feedbackList.appendChild(li);
            });
        });

        // Real-time password confirmation check
        confirmInput.addEventListener('input', () => {
            const password = passwordInput.value;
            const confirm = confirmInput.value;
            
            if (confirm && password !== confirm) {
                confirmInput.style.borderColor = '#e91e63';
                confirmInput.style.boxShadow = '0 0 0 2px #e91e6355';
            } else {
                confirmInput.style.borderColor = '#263159';
                confirmInput.style.boxShadow = 'none';
            }
        });

        // Form validation
        document.getElementById('changePasswordForm').addEventListener('submit', function (e) {
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = passwordInput.value;
            const confirmPassword = confirmInput.value;
            
            if (!currentPassword) {
                e.preventDefault();
                alert('Please enter your current password.');
                return;
            }
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('New passwords do not match.');
                return;
            }
            
            // Check password strength
            const pwd = newPassword;
            let score = 0;
            if (pwd.length >= 8) score++;
            if (/[A-Z]/.test(pwd)) score++;
            if (/[a-z]/.test(pwd)) score++;
            if (/\d/.test(pwd)) score++;
            if (/[^A-Za-z0-9]/.test(pwd)) score++;
            if (!commonPasswords.includes(pwd.toLowerCase())) score++;
            
            if (score < 4) {
                e.preventDefault();
                alert('Password is too weak. Please make it stronger.');
                return;
            }
        });
    </script>
</body>
</html> 